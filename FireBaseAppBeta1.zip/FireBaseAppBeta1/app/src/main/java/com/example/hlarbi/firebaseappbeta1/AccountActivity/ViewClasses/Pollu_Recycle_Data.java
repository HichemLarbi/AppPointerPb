package com.example.hlarbi.firebaseappbeta1.AccountActivity.ViewClasses;

public class Pollu_Recycle_Data {

    public static String[] title_pollu = new String[]{
            "co","no2","o3","pm10","pm25","so2"
    };
    public static String[] number_pollu = new String[]{
            "101.25","9.49","31.4","3","5.22","0"
    };
    public static String[] unity_pollu = new String[]{
            "ppb","ppb","ppb","ug/m3","ug/m3","ppb"
    };

}
