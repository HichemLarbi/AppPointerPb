package com.example.hlarbi.firebaseappbeta1.AccountActivity.ViewClasses.linechart_animation_pollu;

public class DrawData {

	private int startX;
	private int startY;

	private int stopX;
	private int stopY;

	public int getStartX() {
		return startX;
	}

	public void setStartX(int startX) {
		this.startX = startX;
	}

	public int getStartY() {
		return startY;
	}

	public void setStartY(int startY) {
		this.startY = startY;
	}

	public int getStopX() {
		return stopX;
	}

	public void setStopX(int stopX) {
		this.stopX = stopX;
	}

	public int getStopY() {
		return stopY;
	}

	public void setStopY(int stopY) {
		this.stopY = stopY;
	}
}
